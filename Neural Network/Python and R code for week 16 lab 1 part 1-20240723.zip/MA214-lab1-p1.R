#+, -, *, /
3+4; 3-4; 3*4; 3/4
5^2; 3^7
Price<-2.5; Price.1<-2.5; 2.5->Price.2
Price; Price.1; Price.2

# Character
x<-'MA214'; x
x<-"MA214"; x
x<-"It isn't an orange."; x

# vector
a<-c(1,3,4,7,8); a
b<-c("apple", "pear", "banana"); b
a.1<-1:10; a.2<-seq(from=2, to=3, by=0.2); a.1; a.2
length(a); length(b)

a[1]; a[5]; a[-1]

print("MA214")
print(paste("Fruit we have is:", b[1]))

#list
a<-list(num=c(1,2,3), char=c("apple", "pear"))
a; a$num; a$char
length(a)
a[[1]][2]; a[[2]][1]

#matrix
matrix(c(1,2,3,4,5,6), nrow=3, ncol=2)
matrix(c("apple", "banana", "orange", "pear"), nrow=2, ncol=2)

#array
x<-array(1:12, dim=c(2,3,2)); x
x[,,1]
x[,,2]

#data frame
a <- 1:4; M <- c(10, 35, 1, 30); b<-data.frame(a, M) 
M.1<-10; b.1<-data.frame(a,M.1)
M.2<-c(10,11); b.2<-data.frame(a, M.2)

#factor
# Create a vector.
fruit<- c('orange','apple','apple','Mongo','pear','apple','Mongo')
# Create a factor object.
factor_fruit<- factor(fruit)
# Print the factor.
factor_fruit
levels(factor_fruit)
nlevels(factor_fruit)


#while
a<-0;b<-3
while(a<10){
  print(a)
  a<-a+b
  b<-b+1
}

a<-0; b<-3
while(a<10){
  print(a)
  a<-a+b
  b<-b+1
}
print(b)

#for
words<-c("MA214", "Network", "Analysis")
for(i in words){
  print(paste(i, length(i)))
}

words<-c("MA214", "Network", "Analysis")
for(i in words){
  print(paste(i, nchar(i)))
}

for(i in 1:length(words)){
  print(paste(i, words[i], nchar(words[i])))
}

x<-readline("Enter an integer:")
if(x<0){
  print("Negative")
}else if(x==0){
  print("Zero")
}else{
  print("Positive")
}

#functions
myfun<-function(n){
  a<-0; b<-3
  while(a<n){
    print(a)
    a<-a+b; b<-b+1
  }
}

myfun(20)

myfun<-function(a,b,n){
  while(a<n){
    print(a)
    a<-a+b; b<-b+1
  }
}

myfun(0,3,20)

myfun<-function(a,b,n){
  t<-(a+b)^n
  return(list(t=t,a=a,b=b))
}

res<-myfun(3,2,0)
