#install.packages("igraph")
#Use the library "igraph"
library(igraph)
library(readxl)

#####################################################
#############        Q1      ################################
##########################################################
#Generate two networks G1 and G2
##################
######Generate the network G1
#Read the xlsx file as a dataframe
#You need to change the path to your own
data <- read_excel("/Users/dongjiaoge/Desktop/MA214/Week 21/lab_6_p1.xlsx", sheet = "G1")
#Create the network using the imported dataframe
G1 = graph.data.frame(d = data, directed = FALSE)
plot(G1)
##################
######Generate the network G2
data <- read_excel("/Users/dongjiaoge/Desktop/MA214/Week 21/lab_6_p1.xlsx", sheet = "G2")
#Create the network using the imported dataframe
G2 = graph.data.frame(d = data, directed = FALSE)
plot(G2)
##################
######Generate the network G3
data <- read_excel("/Users/dongjiaoge/Desktop/MA214/Week 21/lab_6_p1.xlsx", sheet = "G3")
#Create the network using the imported dataframe
G3 = graph.data.frame(d = data, directed = FALSE)
plot(G3)
##################
######Generate the network G4
data <- read_excel("/Users/dongjiaoge/Desktop/MA214/Week 21/lab_6_p1.xlsx", sheet = "G4")
#Create the network using the imported dataframe
G4 = graph.data.frame(d = data, directed = FALSE)
plot(G4)

###################
#Closeness centrality
closeness(G1)
closeness(G2)
closeness(G3)
closeness(G4)

###################
#Betweenness centrality
betweenness(G1)
betweenness(G2)
betweenness(G3)
betweenness(G4)

#####################
#Cliques
cliques(G1)
cliques(G2)
cliques(G3)
cliques(G4)

#####################
#Find k-cores
coreness(G1)
coreness(G2)
coreness(G3)
coreness(G4)

####################
#Example
G=read_graph(file='/Users/dongjiaoge/Desktop/MA214/Week 21/dolphins/Dolphins.gml', format="gml")

png("/Users/dongjiaoge/Desktop/MA214/Week 21/dolphins/dolphine.png", width = 1500, height = 1500)
plot(G,vertex.size=5)
dev.off()

degrees=degree(G)
closen=closeness(G)
between=betweenness(G)

df <- data.frame(node=V(G)$label, degree=degrees, closeness=closen, betweenness=between)

print(paste("The nodes with maximum degrees is/are ", max(degrees), 
      "The maximum degree is", V(G)$label[which(degrees==max(degrees))]))
print(paste("The nodes with maximum closeness centrality is/are ", max(closen), 
      "The maximum closeness centrality is", V(G)$label[which(closen==max(closen))]))
print(paste("The nodes with maximum betweenness centrality is/are ", max(between), 
      "The maximum betweenness centrality is", V(G)$label[which(between==max(between))]))


cliques(G)


#####################
#Find k-cores
core=coreness(G)
index=which(core==max(core))
color=rep("cyan", length=length(V(G)))
color[index]="red"
V(G)$color=color

png("/Users/dongjiaoge/Desktop/MA214/Week 21/dolphins/dolphine1.png", width = 1500, height = 1500)
plot(G,vertex.size=5)
dev.off()
