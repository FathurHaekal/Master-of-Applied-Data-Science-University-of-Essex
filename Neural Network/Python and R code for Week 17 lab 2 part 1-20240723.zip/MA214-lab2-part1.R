#install.packages("igraph")
library(igraph)

#create a graph
G <- make_graph( edges=c(1,2, 1,3, 2, 3, 2, 4), directed=FALSE ) 
plot(G) 

#Count the number of nodes
gorder(G)
#Count the number of edges
gsize(G)
#Convert a graph to the adjacency matrix
as_adjacency_matrix(G)

#Create a graph using adjacency matrix 
a<-matrix(c(0,1,1,1,1,0,1,1,1,1,0,0,1,1,0,0),nrow = 4)
a
G<-graph_from_adjacency_matrix(a,mode="undirected")
plot(G)

#Create a weighted graph
G<-make_graph(c(1, 2, 3,4, 4,2, 1,3, 2,5, 1,4), directed = FALSE)
E(G)$weight<-c(3, 0.5, 1.2, 2, 2.2, 1)
plot(G, edge.label = E(G)$weight)

#Create a graph with multi-edges and self-loops
G<-make_graph(c(1,2, 1,3, 1,3, 2,6, 2,4, 4,5, 4,5, 4,6, 2,2,6,6), directed = FALSE)
plot(G)

#Create a directed graph
G<-make_graph(c(1,2, 1,3, 2,3, 2,4, 4,1), directed = TRUE)
plot(G)

#Check for acyclic
G<-make_graph(c(1,2, 1,3, 2,3, 4,2, 4,1), directed = TRUE)
is_dag(G)