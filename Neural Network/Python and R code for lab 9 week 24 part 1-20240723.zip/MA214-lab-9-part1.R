
library(igraph)

#Generate the small-workd network using watt.strogatz model with p=0.05, p=0, and p=1
g <- watts.strogatz.game(dim=1,size=20,nei=3, p=0.05)
plot(g, layout=layout.circle)

g <- watts.strogatz.game(dim=1,size=20,nei=3, p=0)
plot(g, layout=layout.circle)

g <- watts.strogatz.game(dim=1,size=20,nei=3, p=1)
plot(g, layout=layout.circle)

########## Oberve the trend of L(p)/L(0), C(p)/C(0)
p=c(0, 0.01, 0.02, 0.03, 0.04, 0.05, 0.06, 0.07, 0.08, 0.09, 0.1, 1)
n=1000
k=10

L_f=1:length(p)
C_f=1:length(p)

G_0=watts.strogatz.game(dim=1,size=n,nei=k/2, p=0)
L_0=average.path.length(G_0)
C_0=transitivity(G_0, "global")


for (i in 1:length(p)){
  G=watts.strogatz.game(dim=1,size=n,nei=k/2, p=p[i])
  L_f[i]=average.path.length(G)/L_0
  C_f[i]=transitivity(G, "global")/C_0
}
  
plot(p, L_f, type="l", col="blue", xlab="p", ylab="fraction",ylim=c(0,1))
lines(p, C_f, col="red")
legend(x = "topright",          # Position
       legend = c("L(p)/L(0)", "C(p)/C(0)"), 
       col = c("blue", "red"), lty=c(1,1), cex=0.7)

#Use the average local clustering coefficient

p=c(0, 0.01, 0.02, 0.03, 0.04, 0.05, 0.06, 0.07, 0.08, 0.09, 0.1, 1)
n=1000
k=10

L_f=1:length(p)
C_f=1:length(p)

G_0=watts.strogatz.game(dim=1,size=n,nei=k/2, p=0)
L_0=average.path.length(G_0)
C_0=mean(transitivity(G_0, "local"))


for (i in 1:length(p)){
  G=watts.strogatz.game(dim=1,size=n,nei=k/2, p=p[i])
  L_f[i]=average.path.length(G)/L_0
  C_f[i]=mean(transitivity(G, "local"))/C_0
}

plot(p, L_f, type="l", col="blue", xlab="p", ylab="fraction",ylim=c(0,1))
lines(p, C_f, col="red")
legend(x = "topright",          # Position
       legend = c("L(p)/L(0)", "C(p)/C(0)"), 
       col = c("blue", "red"), lty=c(1,1), cex=0.7)

###### Compute the mean degree and global clustering coefficient and comparing with theoretical values
p_0=0 
p_1=1
n=10
k=3

M=1000

degrees_0=1:M
C_0=1:M
degrees_1=1:M
C_1=1:M

for (i in 1:M){
  G=watts.strogatz.game(dim=1,size=n,nei=k, p=p_0)
  degrees_0[i]=mean(degree(G))
  C_0[i]=transitivity(G,"global")
  G=watts.strogatz.game(dim=1,size=n,nei=k, p=p_1)
  degrees_1[i]=mean(degree(G))
  C_1[i]=transitivity(G,"global")
  
}
 

print(paste("The mean degree when p=0:", mean(degrees_0)))
print(paste("The mean global clustering coefficient when p=0:", mean(C_0), 
                     "The theoretical value is", 3*(k*2-2)/(4*(k*2-1))))
print(paste("The mean degree when p=1:", mean(degrees_1)))
print(paste("The mean global clustering coefficient when p=1:", mean(C_1), 
                   "The theoretical value is", k*2/(n-1)))


#Use the average local clustering coefficient
p_0=0 
p_1=1
n=10
k=3

M=1000

degrees_0=1:M
C_0=1:M
degrees_1=1:M
C_1=1:M

for (i in 1:M){
  G=watts.strogatz.game(dim=1,size=n,nei=k, p=p_0)
  degrees_0[i]=mean(degree(G))
  C_0[i]=mean(transitivity(G,"local"))
  G=watts.strogatz.game(dim=1,size=n,nei=k, p=p_1)
  degrees_1[i]=mean(degree(G))
  C_1[i]=mean(transitivity(G,"local"))
  
}
print(paste("The mean degree when p=0:", mean(degrees_0)))
print(paste("The mean clustering coefficient when p=0:", mean(C_0), 
            "The theoretical value is", 3*(k*2-2)/(4*(k*2-1))))
print(paste("The mean degree when p=1:", mean(degrees_1)))
print(paste("The mean clustering coefficient when p=1:", mean(C_1[-which(is.na(C_1)==1)]), 
            "The theoretical value is", k*2/(n-1)))


########## Visualize the degree distribution of a small-world network
G=watts.strogatz.game(dim=1,size=100,nei=4/2, p=0.05)
degrees=degree(G)
print("The mean degree is", mean(degrees))
hist(degrees, breaks = 200, freq = FALSE)

######### Visualize the log-log plot of degree

degrees=degree(G)
table_degree=as.data.frame(table(degree(G)))
table_degree$Var1<-as.numeric(as.character(table_degree$Var1))
table_degree$Freq<-as.numeric(as.character(table_degree$Freq))
plot(table_degree$Var1, table_degree$Freq, log = "xy", main="log-log plot", xlab="degrees", ylab="count")

################## Visualize the log-log plot of degrees from a real network
G=read_graph(file='/Users/dongjiaoge/Desktop/MA214/Week 21/Netscience/Netscience.gml', format="gml")

degrees=degree(G)
table_degree=as.data.frame(table(degree(G)))
table_degree$Var1<-as.numeric(as.character(table_degree$Var1))
table_degree$Freq<-as.numeric(as.character(table_degree$Freq))
plot(table_degree$Var1, table_degree$Freq, log = "xy",  main="log-log plot", xlab="degrees", ylab="count")
