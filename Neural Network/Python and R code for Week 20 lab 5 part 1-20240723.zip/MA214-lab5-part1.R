#install.packages("igraph")
#Use the library "igraph"
library(igraph)
library(readxl)
##########################################################
#Generate two undirected networks G1 and G2
##################
######Generate the network G1
#Read xlsx file as dataframe
#You need to change the path to your own
data <- read_excel("/Users/dongjiaoge/Desktop/MA214/Week 20/lab5_1.xlsx", sheet = "G1")
#Create the network using the imported dataframe
G1 = graph.data.frame(d = data, directed = FALSE)
plot(G1)
##################
######Generate the network G2
data <- read_excel("/Users/dongjiaoge/Desktop/MA214/Week 20/lab5_1.xlsx", sheet = "G2")
#Create the network using the imported dataframe
G2 = graph.data.frame(d = data, directed = FALSE)
plot(G2)


############################################################
##### Compute the densities of G1 and G2
print(paste("The density of G1 is ", edge_density(G1, loops=FALSE)))
print(paste("The density of G2 is ", edge_density(G2, loops=FALSE)))

############################################################
##### Compute the degrees of G1 and G2
degree(G1, V(G1), loops=FALSE)
degree(G2, V(G2), loops=FALSE)

#############################################################
##### Compute the mean degrees of G1 and G2
print(paste("The mean degree of G1 is ", sum(degree(G1, loops=FALSE))/length(V(G1))))
print(paste("The mean degree of G2 is ", sum(degree(G2, loops=FALSE))/length(V(G2))))


##########################################################
#Generate two directed networks G3 and G4
##################
######Generate the network G3
#Read xlsx file as dataframe
#You need to change the path to your own
data <- read_excel("/Users/dongjiaoge/Desktop/MA214/Week 20/lab5_1.xlsx", sheet = "G3")
#Create the network using the imported dataframe
G3 = graph.data.frame(d = data, directed = TRUE)
plot(G3)
##################
######Generate the network G4
data <- read_excel("/Users/dongjiaoge/Desktop/MA214/Week 20/lab5_1.xlsx", sheet = "G4")
#Create the network using the imported dataframe
G4 = graph.data.frame(d = data, directed = TRUE)
plot(G4)

############################################################
##### Compute the densities of G3 and G4
print(paste("The density of G3 is ", edge_density(G3, loops=FALSE)))
print(paste("The density of G4 is ", edge_density(G4, loops=FALSE)))

############################################################
##### Compute the in and out degrees of G3 and G4
degree(G3, V(G3), loops=FALSE, mode = "in")
degree(G4, V(G4), loops=FALSE, mode = "in")


degree(G3, V(G3), loops=FALSE, mode = "out")
degree(G4, V(G4),  loops=FALSE, mode = "out")

#############################################################
##### Compute the mean in-degrees and mean out-degrees of G3 and G4
print(paste("The mean in-degree of G3 is ", sum(degree(G3, loops=FALSE, mode = "in"))/length(V(G3))))
print(paste("The mean in-degree of G4 is ", sum(degree(G4, loops=FALSE, mode = "in"))/length(V(G4))))

print(paste("The mean out-degree of G3 is ", sum(degree(G3, loops=FALSE, mode = "out"))/length(V(G3))))
print(paste("The mean out-degree of G4 is ", sum(degree(G4, loops=FALSE, mode = "out"))/length(V(G4))))



##########################################################
###### degree distributions of G1 and G2

G1_degree_distriution<-data.frame(degree=0:max(degree(G1, loops=FALSE)), 
                                  freq=degree_distribution(G1, cumulative = FALSE, loops=FALSE))


G2_degree_distriution<-data.frame(degree=0:max(degree(G2, loops=FALSE)), 
                                  freq=degree_distribution(G2, cumulative = FALSE, loops=FALSE))



par(mfrow=c(1,2))    # set the plotting area into a 1*2 array
barplot(G1_degree_distriution$freq,
        main = "G1",
        xlab = "degree",
        ylab = "frequency",
        ylim = c(0,0.4),
        names.arg = as.character(G1_degree_distriution$degree),
        col = "darkred",
        horiz = FALSE)

barplot(G2_degree_distriution$freq,
        main = "G2",
        xlab = "degree",
        ylab = "frequency",
        ylim = c(0,0.4),
        names.arg = as.character(G2_degree_distriution$degree),
        col = "darkred",
        horiz = FALSE)


dev.off()

