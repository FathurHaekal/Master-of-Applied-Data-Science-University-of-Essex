#install.packages("igraph")
#Use the library "igraph"
library(igraph)
library(readxl)

G0<-erdos.renyi.game(10,15,type = "gnm",directed = FALSE,loops = FALSE)
plot(G0)

G0<-erdos.renyi.game(10,0.2,type = "gnp",directed = FALSE,loops = FALSE)
plot(G0)

n<-50
p<-0.3
G<-vector(mode="list", length = 5000)
m<-1:5000
m_degree<-1:5000
clust_coeff<-1:5000

for (i in 1:5000){
  G[[i]]=erdos.renyi.game(n,p,type = "gnp",directed = FALSE,loops = FALSE)
  m[i]=length(E(G[[i]]))
  m_degree[i]=mean(degree(G[[i]]))
  clust_coeff[i]=transitivity(G[[i]], "global")
}
  

print(paste("The average number of edges:", mean(m), 
      "The theoretical value of average number of edges:", choose(n,2)*p))
print(paste("The mean degree:", mean(m_degree), 
      "The theoretical value of the mean degree:", (n-1)*p))
print(paste("The mean of the clusteirng coefficient:", mean(clust_coeff),
      "The theoretical value of the mean clustering coefficient", p))



n_1<-c(50, 500, 7000, 15000)
p<-0.3
G<-vector(mode="list", length = length(n_1))
degrees<-vector(mode="list", length = length(n_1))


for (i in 1:length(n_1)){
  G[[i]]=erdos.renyi.game(n_1[i], p, type = "gnp", directed = FALSE, loops = FALSE)
  degrees[[i]]<-degree(G[[i]])
}

distn<-vector(mode="list", length = length(n_1))
for (i in 1:length(n_1)){
  distn[[i]]<-dbinom(seq(min(degrees[[i]])-1, max(degrees[[i]])+1, by=1), size=n_1[i], prob=p) 
}

png("/Users/dongjiaoge/Desktop/MA214/Week 23/degree.png", width = 500, height = 500)
par(mfrow=c(2,2))
hist(degrees[[1]], breaks = 10, freq = FALSE)
lines(seq(min(degrees[[1]])-1, max(degrees[[1]])+1, by=1), distn[[1]], col="blue")
hist(degrees[[2]], breaks = 30, freq = FALSE)
lines(seq(min(degrees[[2]])-1, max(degrees[[2]])+1, by=1), distn[[2]], col="blue")
hist(degrees[[3]], breaks = 100, freq = FALSE)
lines(seq(min(degrees[[3]])-1, max(degrees[[3]])+1, by=1), distn[[3]], col="blue")
hist(degrees[[4]], breaks = 100, freq = FALSE)
lines(seq(min(degrees[[4]])-1, max(degrees[[4]])+1, by=1), distn[[4]], col="blue")
dev.off()


#### Dolphins
#Read the network
G<-read_graph(file='/Users/dongjiaoge/Desktop/MA214/Week 21/dolphins/Dolphins.gml', format="gml")
n<-length(V(G))
m<-length(E(G))
degree<-degree(G, V(G))
p<-2*m/(n*(n-1))
G1<-erdos.renyi.game(n,p,type = "gnp",directed = FALSE,loops = FALSE)
degree_1<-degree(G1, V(G1))

## Draw the degree distributions
distn<-vector(mode="list", length = 2)
distn[[1]]<-dbinom(seq(min(degree)-1, max(degree)+1, by=1), size=n-1, prob=p) 
distn[[2]]<-dbinom(seq(min(degree_1)-1, max(degree_1)+1, by=1), size=n-1, prob=p) 

png("/Users/dongjiaoge/Desktop/MA214/Week 23/degree_1.png", width = 500, height = 500)
par(mfrow=c(1,2))
hist(degree, breaks = 5, freq = FALSE, ylim = c(0, 0.3), main = "dolphin", xlab = "degree")
lines(seq(min(degree)-1, max(degree)+1, by=1), distn[[1]], col="blue")
hist(degree_1, breaks = 5, freq = FALSE, ylim = c(0, 0.3), main = "random",  xlab = "degree")
lines(seq(min(degree_1)-1, max(degree_1)+1, by=1), distn[[2]], col="blue")
dev.off()


