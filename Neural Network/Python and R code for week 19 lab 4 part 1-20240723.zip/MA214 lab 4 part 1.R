#install.packages("igraph")
#Use the library "igraph"
library(igraph)

##########################################################
#Example 1
#Generate a network G1
G1 <- graph.empty(directed = F)
#The nodes in node list
nodelist<-1:10
#The list of edges
edge.list <- c(1, 2, 1, 3, 1,8, 2,3, 2,4, 2,5, 2,6, 2,7, 3,6, 3,9, 4,5, 4, 7, 
               4,8, 5,7, 6,9)

G1 <- add.vertices(G1,nv=length(nodelist),attr=list(name=nodelist))
G1 <- add.edges(G1,edge.list)
plot(G1)

#list out all the paths from source to a target, or all the paths from a certain source
all_simple_paths(G1, 1, 5)
all_simple_paths(G1, 1)

#
shortest_paths(G1,1,6)
shortest_paths(G1,1)
all_shortest_paths(G1, 1, 6)
all_shortest_paths(G1,1)

#
shortest.paths(G1,1,6)
shortest.paths(G1,1)

#
diameter(G1, directed = FALSE) #Infinite values are neglected 

#
is_connected(G1)


# remove node 10 from G1
G2 <-make_graph(c(1, 2, 1, 3, 1, 8, 2, 3, 2,4, 2,5, 2,6, 2,7, 3,6, 3,9, 
                  4, 5, 4, 7, 4, 8, 5,7, 6,9), directed=FALSE)
plot(G2)

diameter(G2)
is_connected(G2)

###################################################################
#Example 2
G3 <-make_graph(c(1, 2, 1, 3, 1,5, 2,6, 3,4, 4,5, 5,6), directed = FALSE)
plot(G3)

#using a for loop to obtain the shortest path across each pair of nodes
s_p_all<-vector(mode="list", length=gorder(G3))
for (i in 1: gorder(G3)){
  s_p_all[[i]]<-shortest_paths(G3,i)$vpath
}
#using a for loop to obtain the lengths of the shortest paths across each pair of nodes
s_p_len<-vector(mode="list", length=gorder(G3))
for (i in 1: gorder(G3)){
  s_p_len[[i]]<-shortest.paths(G3,i)
}

#Compute diameter and check whether the network is a connected network
diameter(G3)
is_connected(G3)

########################################################################
#Example 3
G4 <-make_graph(c(1, 2, 1, 3, 1,8, 2,3, 2,4, 2,5, 2,6, 2,7, 3,6, 3,9,
                  4,5, 4, 7, 4,8, 5,7, 6,9), directed =TRUE )
plot(G4)
#using a for loop to obtain the shortest path across each pair of nodes
s_p_all<-vector(mode="list", length=gorder(G4))
for (i in 1: gorder(G4)){
  s_p_all[[i]]<-shortest_paths(G4,i)$vpath
}
#using a for loop to obtain the lengths of the shortest paths across each pair of nodes
s_p_len<-vector(mode="list", length=gorder(G4))
for (i in 1: gorder(G4)){
  s_p_len[[i]]<-shortest.paths(G4,i)
}
#only "weak" and "strong" two modes you can choose
is.connected(G4, mode = "weak")
is.connected(G4, mode = "strong")
#compute diameter
diameter(G4, directed = TRUE)

############################################################################
#Example 4
G5 <-make_graph(c(1, 2, 1, 3, 2,4, 3,4, 4,5, 4,6, 5,7, 6,7), directed = FALSE)
plot(G5)
#the number of edge/node-independent paths between two nodes
edge_disjoint_paths(G5, 1, 7)
vertex_disjoint_paths(G5, 1, 7)

############################################################################
#Example 5
G6 <-make_graph(c(1, 2, 2, 3, 4,5, 6,7, 6,8, 7,8, 7,9), directed = FALSE)
plot(G6)
components(G6) #membership with the same order for the nodes listed by V(G)
as_adjacency_matrix(G6)
A = nx.adjacency_matrix(G6)
#directed network
G7 <-make_graph(c(1, 2, 1,4, 2,3, 3,1, 5,6, 6,7, 7,8, 8,5,
                  7,9, 7,10, 9,10), directed = TRUE)
plot(G7)
components(G7, mode = "weak") #membership with the same order for the nodes listed by V(G)
components(G7, mode = "strong")


