#install.packages("igraph")
#Use the library "igraph"
library(igraph)
library(readxl)

#####################################################

##########################################################
#Compute clustering coefficient
##################
######Generate the network G1
#Read the xlsx file as a dataframe
#You need to change the path to your own
data <- read_excel("/Users/dongjiaoge/Desktop/MA214/Week 22/lab_7_p1.xlsx", sheet = "G1")
#Create the network using the imported dataframe
G1 = graph.data.frame(d = data, directed = FALSE)
plot(G1)
#Global clustering coefficient
transitivity(G1, type="global")
#Local clustering coefficient
transitivity(G1, type="local")
#Average clustering coefficient
mean(transitivity(G1, type="local"))
#######################################
###### Modularity
######Generate the network G2
data <- read_excel("/Users/dongjiaoge/Desktop/MA214/Week 22/lab_7_p1.xlsx", sheet = "G2")
#Create the network using the imported dataframe
G2 = graph.data.frame(d = data, directed = FALSE)
plot(G2)

##modularity
nodes<-V(G2)
nodes
#partition: {1,2,3}, {4,5,6,7}, {8,9,10}, {11,12,13}
modularity(G2, c(1, 1, 1, 2, 2, 2, 2, 4, 3, 3, 3, 4, 4))
#Partition: {1,2,4,5,6,7}, {3,8,9,10,11,12,13}
modularity(G2, c(1, 1, 2, 1, 1, 1, 1, 2, 2, 2, 2, 2, 2))
#Using the k-core degree as a partition
modularity(G2, coreness(G2))

#############################################
####### modularity of a bipartite network

#Create a bipartite network
G3 <- graph.empty(directed = F)
#The nodes in nodelist1, and nodelist2 are unique values.
nodelist1<- c("F1", "F2","F3","F4")
nodelist2 <- c("A1", "A2", "A3", "A4", "A5", "A6", "A7")
#The list of edges
edge.list <- c("F1", "A1", "F1", "A2", "F1", "A3", "F1", "A6", "F2", "A1", 
               "F2", "A3", "F2", "A7", "F3", "A3", "F3", "A5", "F4", "A4", "F4","A7")
#add nodes: "TRUE" or "FALSE" in "type" indicate two modes of nodes.
G3 <- add.vertices(G3,nv=length(nodelist1),attr=list(name=nodelist1), type=rep(FALSE,length(nodelist1)))
G3 <- add.vertices(G3,nv=length(nodelist2),attr=list(name=nodelist2), type=rep(TRUE,length(nodelist2)))
G3 <- add.edges(G3,edge.list)

#Print out the created ipartite network
print(G3, v=TRUE)
shape <- ifelse(V(G3)$type, "circle", "square") # assign shape by node type
col <- ifelse(V(G3)$type, "red", "yellow") # assign color by node type
plot(G3, vertex.shape = shape, layout=layout_as_bipartite, vertex.color = col)
###### Remark that the "membership" vector can only be formed by the integers larger than 0.
modularity(G3, as.numeric(V(G3)$type)+1)

#################################################
######### modularity of cycle graphs
n<-seq(10,1000, 90)
n
for (i in n){
  G4 <- make_ring(i)
  # Get the partition that achieves the highest modularity value
  group<-cluster_fast_greedy(G4)
  # Compute the correspondence modularity
  print(modularity(G4,membership(group)))
}

  
